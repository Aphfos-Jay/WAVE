package com.example.remote

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class GalleryFragment : Fragment() {

    private lateinit var galleryRecyclerView: RecyclerView
    private lateinit var refreshButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var galleryAdapter: GalleryAdapter

    private val ws = WebSocketManager.getInstance()
    private val uiHandler = Handler(Looper.getMainLooper())

    private val fragmentWsListener: (type: String, content: String) -> Unit = { type, content ->
        uiHandler.post {
            // ProgressBar는 각 케이스 시작 시 보이고, 응답 처리 후 숨깁니다.
            when (type) {
                "FindCapResult" -> {
                    progressBar.visibility = View.GONE
                    try {
                        // ▼▼▼ [버그 수정] JSONObject를 먼저 파싱하고, 그 안에서 "Items" JSONArray를 추출 ▼▼▼
                        val jsonObject = JSONObject(content)
                        val jsonArray = jsonObject.getJSONArray("Items") // <--- 이 부분이 핵심 수정사항입니다.
                        // ▲▲▲ [버그 수정] ▲▲▲

                        val photoItems = mutableListOf<PhotoItem>()
                        for (i in 0 until jsonArray.length()) {
                            val item = jsonArray.getJSONObject(i)
                            photoItems.add(PhotoItem(
                                id = item.getString("id"), // 서버 응답 키는 소문자 'id'
                                datetime = item.getString("datetime"), // 서버 응답 키는 소문자 'datetime'
                                thumbnailUrl = item.getString("url") // 서버 응답 키는 소문자 'url'
                            ))
                        }
                        galleryAdapter.submitList(photoItems)
                        if (isAdded) Toast.makeText(context, "${photoItems.size}개의 사진을 찾았습니다.", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Log.e("GalleryFragment", "FindCapResult 파싱 오류", e)
                        if (isAdded) Toast.makeText(context, "사진 목록을 파싱하는데 실패했습니다.", Toast.LENGTH_SHORT).show()
                    }
                }
                "CapGetResult" -> {
                    progressBar.visibility = View.GONE
                    try {
                        val jsonObject = JSONObject(content)
                        val photoUrl = jsonObject.getString("Url")
                        PhotoViewFragment.newInstance(photoUrl).show(parentFragmentManager, "photo_view")
                    } catch (e: Exception) {
                        Log.e("GalleryFragment", "CapGetResult 파싱 오류", e)
                        if (isAdded) Toast.makeText(context, "사진 URL을 가져오는데 실패했습니다.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_gallery, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        galleryRecyclerView = view.findViewById(R.id.galleryRecyclerView)
        refreshButton = view.findViewById(R.id.refreshButton)
        progressBar = view.findViewById(R.id.progressBar)

        setupRecyclerView()
        ws.addEventListener(fragmentWsListener)

        refreshButton.setOnClickListener {
            loadPhotoList()
        }
        loadPhotoList()
    }

    private fun setupRecyclerView() {
        galleryAdapter = GalleryAdapter { photoItem ->
            loadFullPhoto(photoItem.id)
        }
        galleryRecyclerView.adapter = galleryAdapter
        galleryRecyclerView.layoutManager = LinearLayoutManager(context)
    }

    private fun loadPhotoList() {
        progressBar.visibility = View.VISIBLE
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val to = sdf.format(Date())
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, -1)
        val from = sdf.format(cal.time)
        val findCapMessage = JsonFactory.createFindCaps(from, to, limit = 100)
        ws.sendText(findCapMessage)
        Log.d("GalleryFragment", "사진 목록 요청: $findCapMessage")
    }

    private fun loadFullPhoto(photoId: String) {
        progressBar.visibility = View.VISIBLE
        val getCapMessage = JsonFactory.createCapGet(photoId)
        ws.sendText(getCapMessage)
        Log.d("GalleryFragment", "고화질 사진 요청: $getCapMessage")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        ws.removeEventListener(fragmentWsListener)
    }
}