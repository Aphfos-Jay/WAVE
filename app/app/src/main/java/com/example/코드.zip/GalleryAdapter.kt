package com.example.remote

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

// 각 사진 아이템의 데이터를 담을 클래스
data class PhotoItem(
    val id: String,
    val datetime: String,
    val thumbnailUrl: String
)

class GalleryAdapter(
    private val onItemClick: (PhotoItem) -> Unit
) : RecyclerView.Adapter<GalleryAdapter.PhotoViewHolder>() {

    private var photoList: List<PhotoItem> = emptyList()

    fun submitList(newList: List<PhotoItem>) {
        photoList = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.gallery_item, parent, false)
        return PhotoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        val photoItem = photoList[position]
        holder.bind(photoItem, onItemClick)
    }

    override fun getItemCount(): Int = photoList.size

    class PhotoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imageView: ImageView = itemView.findViewById(R.id.photoImageView)
        private val dateView: TextView = itemView.findViewById(R.id.dateTextView)

        fun bind(item: PhotoItem, onItemClick: (PhotoItem) -> Unit) {
            dateView.text = item.datetime
            // Glide 라이브러리를 사용해 썸네일 URL을 이미지뷰에 로드
            Glide.with(itemView.context)
                .load(item.thumbnailUrl)
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_background) // 로딩 중 이미지
                .into(imageView)

            // 아이템 클릭 이벤트 설정
            itemView.setOnClickListener {
                onItemClick(item)
            }
        }
    }
}